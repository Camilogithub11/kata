package org.example;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class put {

    public static void main(String[] args) {
        System.out.println("PUT exitoso:");
        updateProduct("https://fakestoreapi.com/products/1"); // válido

        System.out.println("\nPUT fallido:");
        updateProduct("https://fakestoreapi.com/productos/1"); // URL incorrecta (intencional)
    }

    public static void updateProduct(String url) {
        HttpClient client = HttpClient.newHttpClient();

        String jsonBody = "{\n" +
                "  \"title\": \"Ejemplo\",\n" +
                "  \"price\": 99.99\n" +
                "}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            int status = response.statusCode();

            System.out.println("Código de estado: " + status);
            estadoservi.validateStatus(status, 200, "PUT");

            if (status >= 200 && status < 300) {
                System.out.println("Actualización exitosa:\n" + response.body());
            } else {
                System.out.println("Error al actualizar:\n" + response.body());
            }

        } catch (IOException | InterruptedException e) {
            System.out.println("Error de conexión al hacer PUT: " + e.getMessage());
        }
    }
}
