package org.example;

public class estadoservi {

    public static void validateStatus(int actualStatus, int expectedStatus, String metodo) {
        if (actualStatus == expectedStatus) {
            System.out.println("[" + metodo + "] Código esperado: " + expectedStatus);
        } else {
            System.out.println("[" + metodo + "] Esperado: " + expectedStatus + ", pero fue: " + actualStatus);
        }
    }
}

