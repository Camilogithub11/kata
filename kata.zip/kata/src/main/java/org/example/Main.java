package org.example;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Main {

    public static void main(String[] args) {

        System.out.println("GET exitoso:");
        getFromApi("https://fakestoreapi.com/products");


        System.out.println("\n GET fallido:");
        getFromApi("https://fakestoreapi.com/productos"); // endpoint incorrecto a propósito
    }


    public static void getFromApi(String url) {
        HttpClient client = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            int status = response.statusCode();
            System.out.println("Código de estado: " + status);

            if (status >= 200 && status < 300) {
                System.out.println(" Éxito:\n" + response.body());
            } else {
                System.out.println(" Fallo:\n" + response.body());
            }

        } catch (IOException | InterruptedException e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
    }
}

