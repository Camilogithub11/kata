package org.example;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;

import org.json.JSONArray;
import org.json.JSONObject;

public class sonbudy {

    public static void main(String[] args) {
        HttpClient client = HttpClient.newHttpClient();
        String url = "https://fakestoreapi.com/products";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            int status = response.statusCode();
            System.out.println("Código de estado: " + status);

            if (status >= 200 && status < 300) {
                String body = response.body();


                if (body.trim().startsWith("[")) {
                    JSONArray jsonArray = new JSONArray(body);
                    System.out.println(jsonArray.toString(4)); // indentación de 4 espacios
                } else {
                    JSONObject jsonObject = new JSONObject(body);
                    System.out.println(jsonObject.toString(4));
                }

            } else {
                System.out.println(" Error al obtener JSON: " + response.body());
            }

        } catch (IOException | InterruptedException e) {
            System.out.println(" Error de conexión: " + e.getMessage());
        }
    }
}
