package org.example;

import java.net.URI;
import java.net.http.*;
import java.util.concurrent.*;

public class serviparalero {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(3);

        executor.submit(() -> {
            try {
                callGet();
            } catch (Exception e) {
                System.out.println("GET error: " + e.getMessage());
            }
        });

        executor.submit(() -> {
            try {
                callPost();
            } catch (Exception e) {
                System.out.println("POST error: " + e.getMessage());
            }
        });

        executor.submit(() -> {
            try {
                callPut();
            } catch (Exception e) {
                System.out.println("PUT error: " + e.getMessage());
            }
        });

        executor.shutdown();
    }

    // GET
    private static void callGet() throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://fakestoreapi.com/products/1"))
                .GET()
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("GET → " + response.statusCode());
    }

    // POST
    private static void callPost() throws Exception {
        String json = """
                {
                    "title": "Desde POST",
                    "price": 99.99
                }
                """;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://fakestoreapi.com/products"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("POST → " + response.statusCode());
    }

    // PUT
    private static void callPut() throws Exception {
        String json = """
                {
                    "title": "Desde PUT",
                    "price": 88.88
                }
                """;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://fakestoreapi.com/products/1"))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("PUT → " + response.statusCode());
    }
}
